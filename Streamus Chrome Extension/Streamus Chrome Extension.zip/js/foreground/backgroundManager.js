﻿define(function() {
    'use strict';
    
    return chrome.extension.getBackgroundPage().BackgroundManager;
})