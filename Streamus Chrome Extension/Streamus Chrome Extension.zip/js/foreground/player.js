﻿define(function () {
    'use strict';

    return chrome.extension.getBackgroundPage().YouTubePlayer;
})