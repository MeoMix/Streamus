﻿define(function () {
    'use strict';

    return Object.freeze({
        DISABLED: 0,
        REPEAT_VIDEO_ENABLED: 1,
        REPEAT_PLAYLIST_ENABLED: 2
    });
});