﻿//  A list of supported data sources when parsing YouTube URLs
var DataSources = Object.freeze({
    YOUTUBE_PLAYLIST: 0,
    YOUTUBE_CHANNEL: 1,
});